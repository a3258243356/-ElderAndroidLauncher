#!/system/bin/sh
# =============================================================================
# 老人桌面 · Magisk 模块（late_start service，由 Magisk 以 root 身份自动执行）
#
#   v3.1 加固（对应 App 新增功能：拨号盘 + 通话自动免提 / 网格列数 / 低电量弹窗）：
#     - pm grant 自动授予 READ_PHONE_STATE（通话免提）、CAMERA（手电筒）、
#       存储（自定义桌面背景）等危险权限，老人不用处理系统授权框；
#     - 自动开启并设置无障碍服务（enabled_accessibility_services），刷完不用手动开；
#     - 巡检每 60 秒复查一次，权限被重置 / 无障碍被关掉都会自动补回。
#
#   v3.2：每小时强制清理一次内存 —— 对所有「第三方应用」执行 am force-stop，
#     只保留老人桌面、微信、电话相关（拨号 / 通话 / 联系人 / 短信）和当前前台应用；
#     系统进程用 pm list packages -3 天然排除，不会碰。
#
#   ★ 模块只需要刷一次。以后更新 App 不用重新打包 / 重刷模块：
#     把新的 APK 放到手机上的任意一个位置即可（优先第一个）：
#       1) /sdcard/ElderLauncher.apk              （推荐：adb push 到这就行）
#       2) /sdcard/Download/ElderLauncher.apk
#       3) /data/local/tmp/ElderLauncher.apk
#       4) /data/local/tmp/elder_update/*.apk     （放多个时取最新的那个）
#       5) 模块内置的 system/priv-app/ElderLauncher/ElderLauncher.apk（兜底）
#     - 开机时：发现 APK 指纹变了 → 自动 pm install 升级（保留 App 数据）
#     - 运行中：巡检每 60 秒检查一次，换了 APK 就自动装 + 自动重新拉起桌面
#     - 装失败只重试到「换下一个新 APK」为止，不会每 60 秒疯狂重试
#     - 想关掉自动更新：adb shell su -c "touch /data/adb/elder_no_autoupdate"
#
#   主要功能：
#   1) 等待开机完成
#   2) 自动安装 / 升级 APK（按上面的路径找）
#   3) 设为系统默认桌面（HOME），无需手工选择
#   4) 拉起桌面
#   5) oom_score_adj = -1000 保活
#   6) 加入省电 / 待机白名单
#   7) 常驻巡检（每 5 秒）：
#        - 黑名单应用出现在前台 → 强制回到老人桌面 + 只强杀该应用
#          （★ 不用 am kill-all：它会把桌面进程 / 无障碍服务 / 巡检脚本一起杀掉）
#        - 每 30 秒补写一次 oom_score_adj
#        - 每 60 秒检查一次 APK 更新（热更新）
#        - 桌面进程不在了 → 重新拉起
#
# 黑名单 / 白名单文件由 App 导出（无需存储权限）：
#   /sdcard/Android/data/com.example.androidlauncher/files/elder_blacklist.txt
#   /sdcard/Android/data/com.example.androidlauncher/files/elder_whitelist.txt
#
# 日志：adb shell su -c "cat /data/local/tmp/elder_launcher.log"
# 关闭巡检：adb shell su -c "touch /data/adb/elder_no_watchdog" 后重启
# =============================================================================

PKG=com.example.androidlauncher
HOME_ACT="$PKG/.ui.MainActivity"
MODDIR=${0%/*}
LOG=/data/local/tmp/elder_launcher.log
WATCH=/data/local/tmp/elder_watchdog.sh
DATA_DIR=/sdcard/Android/data/$PKG/files
BLACK_FILE=$DATA_DIR/elder_blacklist.txt
WHITE_FILE=$DATA_DIR/elder_whitelist.txt
DEF_BLACK=/data/local/tmp/elder_default_blacklist.txt   # 模块内置兜底名单：其它桌面
INSTALL_FLAG=$DATA_DIR/elder_install_block.txt          # App 导出的「强制阻止安装模式」开关
INSTALL_LIST=/data/local/tmp/elder_installer_blocklist.txt  # 模块内置：安装器 / 应用市场（前台拦截）
MARKET_LIST=/data/local/tmp/elder_market_blocklist.txt      # 模块内置：应用市场（直接冻结）

# APK 自动更新相关
MARK=/data/local/tmp/elder_apk.md5          # 已成功安装的 APK 指纹
FAILMARK=/data/local/tmp/elder_apk_fail     # 安装失败的指纹（换 APK 前不再重试）
TMP_APK=/data/local/tmp/elder_install.apk   # 安装用的中转副本
UPDATE_DIR=/data/local/tmp/elder_update     # 丢 APK 进这个目录也能被识别
NO_AUTOUPDATE=/data/adb/elder_no_autoupdate

# 日志超过 512KB 就清空，避免长期运行无限增长
if [ -f "$LOG" ]; then
    sz=$(wc -c < "$LOG" 2>/dev/null)
    if [ -n "$sz" ] && [ "$sz" -gt 524288 ]; then
        : > "$LOG" 2>/dev/null
    fi
fi

echo "==== $(date '+%F %T') service.sh start ====" >> "$LOG"

# ---------- 1) 等待开机完成（最多约 120 秒） ----------
i=0
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    i=$((i + 1))
    [ "$i" -gt 60 ] && break
    sleep 2
done
sleep 3
mkdir -p "$UPDATE_DIR" 2>/dev/null

# ---------- 2) APK：自动安装 / 自动升级（刷一次模块，以后只换 APK 就行） ----------

# 找 APK：外部路径优先，模块内置兜底
find_apk() {
    local f
    for f in \
        /sdcard/ElderLauncher.apk \
        /sdcard/Download/ElderLauncher.apk \
        /data/local/tmp/ElderLauncher.apk \
        "$MODDIR/system/priv-app/ElderLauncher/ElderLauncher.apk"; do
        [ -f "$f" ] && { echo "$f"; return 0; }
    done
    # 目录模式：取 elder_update 下最新的一个 apk
    ls -t "$UPDATE_DIR"/*.apk 2>/dev/null | head -1
    return 0
}

# APK 指纹：md5；没有 md5sum 时退化为「大小-修改时间」
apk_md5() {
    local s
    s=$(md5sum "$1" 2>/dev/null | cut -d' ' -f1)
    [ -n "$s" ] || s="s$(wc -c < "$1" 2>/dev/null)-$(date -r "$1" +%s 2>/dev/null)"
    echo "$s"
}

# 安装：先复制到 /data/local/tmp 再装（部分 ROM 不允许 installd 直接读 /sdcard）
# 输出同时写日志并返回给调用方，便于判断失败原因（例如版本降级）
install_apk_from() {
    local src="$1" rc out
    cp -f "$src" "$TMP_APK" 2>/dev/null
    [ -f "$TMP_APK" ] || TMP_APK="$src"
    out=$(pm install -r -g --user 0 "$TMP_APK" 2>&1)
    rc=$?
    echo "[apk  ] install: $src" >> "$LOG"
    echo "$out" >> "$LOG"
    echo "[apk  ] pm install -> $rc" >> "$LOG"
    echo "$out"
    return $rc
}

ensure_apk() {
    local src sum last out rc
    src=$(find_apk)
    if [ -z "$src" ]; then
        echo "[apk  ] 未找到 APK（把新 APK 放到 /sdcard/ElderLauncher.apk 就会自动装上）" >> "$LOG"
        return 1
    fi
    sum=$(apk_md5 "$src")
    last=$(cat "$MARK" 2>/dev/null)
    if pm list packages 2>/dev/null | grep -q "^package:${PKG}\$"; then
        if [ -n "$sum" ] && [ "$sum" = "$last" ]; then
            echo "[apk  ] 已安装且为最新：$src" >> "$LOG"
            return 0
        fi
        echo "[apk  ] 检测到新版本，升级安装：$src" >> "$LOG"
    else
        echo "[apk  ] 未安装，开始安装：$src" >> "$LOG"
    fi
    out=$(install_apk_from "$src")
    rc=$?
    if [ "$rc" -eq 0 ]; then
        echo "$sum" > "$MARK"
        rm -f "$FAILMARK" 2>/dev/null
        return 0
    fi
    # 手机上已装的是更新的版本（比如用 Android Studio 直接装的）→ 不降级，标记后跳过
    case "$out" in
        *DOWNGRADE*)
            echo "[apk  ] 手机上已装的更新，跳过该 APK（不降级）" >> "$LOG"
            echo "$sum" > "$MARK"
            return 0
            ;;
    esac
    echo "[apk  ] 安装失败，下次开机自动重试" >> "$LOG"
    return 1
}
ensure_apk

# ---------- 2.5) 运行时权限 + 无障碍服务（★ v3.1 加固） ----------
# 拨号盘的「通话自动免提」依赖 READ_PHONE_STATE，手电筒依赖 CAMERA，
# 壁纸依赖存储权限 —— 这些危险权限不会因为预装成 priv-app 就自动授予，
# 而老人根本不会处理系统弹出的授权框，所以由模块直接用 pm grant 授予。
# （幂等：已授权就跳过；APK 重装后权限会被重置，巡检里会再补一次）
ACC="$PKG/.service.LauncherAccessibilityService"

# 已授予 → 返回 1（不需要 grant）；未授予 → 返回 0
need_perm() {
    cmd package check-permission "$1" "$PKG" 2>/dev/null | grep -qi "true" && return 1
    return 0
}

grant_perms() {
    for p in \
        android.permission.READ_PHONE_STATE \
        android.permission.CAMERA \
        android.permission.READ_EXTERNAL_STORAGE \
        android.permission.READ_MEDIA_IMAGES; do
        if need_perm "$p"; then
            pm grant "$PKG" "$p" >> "$LOG" 2>&1
            echo "[perm ] grant $p -> $?" >> "$LOG"
        fi
    done
}

# 自动开启无障碍服务：不追加覆盖已有的其它服务，只在缺失时补上
ensure_accessibility() {
    local cur new
    cur=$(settings get secure enabled_accessibility_services 2>/dev/null)
    case "$cur" in
        *"$ACC"*) : ;;
        *)
            if [ -z "$cur" ] || [ "$cur" = "null" ]; then
                new="$ACC"
            else
                new="$cur:$ACC"
            fi
            settings put secure enabled_accessibility_services "$new" >> "$LOG" 2>&1
            echo "[acc  ] enabled_accessibility_services -> $new" >> "$LOG"
            ;;
    esac
    settings put secure accessibility_enabled 1 >> "$LOG" 2>&1
}

grant_perms
ensure_accessibility

# ---------- 3) 设为默认桌面（★ 带校验 + 重试） ----------
# 只 set 一次是不够的：APK 被 pm install 升级、模块重刷、或系统重扫包之后，
# Android 会把「默认主屏幕」清掉（下次按 Home 就弹选择器、或回到原厂桌面）。
# 所以这里设置后立刻校验，没生效就重试；运行期再由巡检兜底。
home_ok() {
    cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -q "$PKG"
}

ensure_home() {
    local i=0
    while [ "$i" -lt 3 ]; do
        if home_ok; then
            echo "[home ] 默认桌面已是 $PKG" >> "$LOG"
            return 0
        fi
        cmd package set-home-activity "$HOME_ACT" >> "$LOG" 2>&1
        echo "[home ] set-home-activity -> $?" >> "$LOG"
        cmd role add-role-holder android.app.role.HOME "$PKG" 0 >> "$LOG" 2>&1
        echo "[role ] add-role-holder -> $?" >> "$LOG"
        i=$((i + 1))
        sleep 3
    done
    home_ok && echo "[home ] 恢复成功" >> "$LOG" || echo "[home ] 仍不是默认桌面，交给巡检继续重试" >> "$LOG"
}
ensure_home

# ---------- 4) 拉起桌面 ----------
am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
echo "[start] am start -> $?" >> "$LOG"
sleep 3

# ---------- 5) 保活：oom_score_adj = -1000 ----------
apply_oom() {
    for d in /proc/[0-9]*; do
        pid=${d#/proc/}
        cmd=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
        case "$cmd" in
            *"$PKG"*)
                echo -1000 > "/proc/$pid/oom_score_adj" 2>/dev/null
                echo -17 > "/proc/$pid/oom_adj" 2>/dev/null
                echo "[oom  ] pid=$pid -> -1000" >> "$LOG"
                ;;
        esac
    done
}
apply_oom
sleep 8
apply_oom

# ---------- 6) 省电 / 待机白名单 ----------
cmd appops set "$PKG" RUN_IN_BACKGROUND allow >> "$LOG" 2>&1
cmd appops set "$PKG" RUN_ANY_IN_BACKGROUND allow >> "$LOG" 2>&1
cmd appops set "$PKG" START_FOREGROUND allow >> "$LOG" 2>&1
# 悬浮窗 / 修改系统设置（屏幕亮度调节与置顶弹窗用）
cmd appops set "$PKG" SYSTEM_ALERT_WINDOW allow >> "$LOG" 2>&1
cmd appops set "$PKG" WRITE_SETTINGS allow >> "$LOG" 2>&1
dumpsys deviceidle whitelist +"$PKG" >> "$LOG" 2>&1
echo "[power] whitelist done" >> "$LOG"

# ---------- 6.5) 模块内置兜底黑名单：所有「别的桌面」 ----------
# 用途：无障碍守护一旦失效（APK 升级后系统会禁用本包的无障碍服务，最常见），
#       老人按 Home / 最近任务跑到原厂桌面就回不来了。这里由 root 巡检兜底：
#       只要发现别的 Launcher 在前台，5 秒内强制拉回老人桌面。
# 只拦「桌面类」应用，不拦设置 / 文件管理等，避免影响配置页的「临时退出」。
cat > "$DEF_BLACK" <<'EOF'
com.miui.home
com.mi.android.globallauncher
com.android.launcher3
com.android.launcher
com.android.launcher2
com.google.android.apps.nexuslauncher
com.google.android.apps.nexuslauncher.stable
com.sec.android.app.launcher
com.huawei.android.launcher
com.oppo.launcher
com.coloros.launcher
com.vivo.launcher
net.oneplus.launcher
com.realme.launcher
EOF
chmod 0644 "$DEF_BLACK" 2>/dev/null
echo "[list ] 内置兜底名单：$(wc -l < "$DEF_BLACK") 个桌面" >> "$LOG"

# ---------- 6.6) 强制阻止安装模式（★ v3.2） ----------
# 与 App 配合：App 负责检测安装界面 + 回桌面，这里做 root 兜底 ——
# 即使 App / 无障碍服务被杀，巡检照样切断安装流程。
# 开关文件由 App 导出（1=开启拦截 / 0=关闭，允许安装）。
# ★ 只拦「新安装」，绝不卸载任何已装应用；电脑 adb install 不受影响。
cat > "$INSTALL_LIST" <<'EOF'
com.android.packageinstaller
com.google.android.packageinstaller
com.miui.packageinstaller
com.miui.securitycenter
com.android.vending
com.xiaomi.market
com.xiaomi.mipicks
com.huawei.appmarket
com.oppo.market
com.heytap.market
com.bbk.appstore
com.sec.android.app.samsungapps
com.tencent.android.qqdownloader
com.qihoo.appstore
com.baidu.appsearch
com.pp.assistant
com.wandoujia.phoenix2
com.taobao.appcenter
EOF
chmod 0644 "$INSTALL_LIST" 2>/dev/null

# 应用市场单独一份：★ 它们能「静默下载 + 自动更新」，不弹任何安装界面，
# 只拦界面拦不住更新，所以开启模式时直接 pm disable-user 冻结（关机重启也保持）。
cat > "$MARKET_LIST" <<'EOF'
com.android.vending
com.xiaomi.market
com.xiaomi.mipicks
com.huawei.appmarket
com.oppo.market
com.heytap.market
com.bbk.appstore
com.sec.android.app.samsungapps
com.tencent.android.qqdownloader
com.qihoo.appstore
com.baidu.appsearch
com.pp.assistant
com.wandoujia.phoenix2
com.taobao.appcenter
EOF
chmod 0644 "$MARKET_LIST" 2>/dev/null

# 安装策略：block = 只留 adb 安装；allow = 恢复手机端安装
apply_install_policy() {
    local mode="$1" p m
    if [ "$mode" = "block" ]; then
        settings put secure install_non_market_apps 0 >> "$LOG" 2>&1
        settings put global install_non_market_apps 0 >> "$LOG" 2>&1
        # 冻结应用市场：杜绝后台静默安装 / 自动更新
        for m in $(cat "$MARKET_LIST" 2>/dev/null); do
            pm disable-user --user 0 "$m" >> "$LOG" 2>&1
            appops set "$m" REQUEST_INSTALL_PACKAGES deny >> "$LOG" 2>&1
        done
        # 撤销第三方应用的「请求安装」权限：浏览器下载 / 微信 / QQ 等发起的安装一并堵死
        for p in $(pm list packages -3 2>/dev/null | cut -d: -f2); do
            [ "$p" = "$PKG" ] && continue
            appops set "$p" REQUEST_INSTALL_PACKAGES deny >> "$LOG" 2>&1
        done
        echo "[inst ] 策略：仅允许 adb 安装（市场已冻结）" >> "$LOG"
    else
        settings put secure install_non_market_apps 1 >> "$LOG" 2>&1
        settings put global install_non_market_apps 1 >> "$LOG" 2>&1
        for m in $(cat "$MARKET_LIST" 2>/dev/null); do
            pm enable "$m" >> "$LOG" 2>&1
            appops set "$m" REQUEST_INSTALL_PACKAGES allow >> "$LOG" 2>&1
        done
        for p in $(pm list packages -3 2>/dev/null | cut -d: -f2); do
            appops set "$p" REQUEST_INSTALL_PACKAGES allow >> "$LOG" 2>&1
        done
        echo "[inst ] 策略：允许手机端安装（市场已解冻）" >> "$LOG"
    fi
}

if [ "$(cat "$INSTALL_FLAG" 2>/dev/null)" = "1" ]; then
    apply_install_policy block
else
    apply_install_policy allow
fi

# 名单文件状态（App 启动后会自动导出）
if [ -f "$BLACK_FILE" ]; then
    echo "[list ] blacklist: $(wc -l < "$BLACK_FILE") 行" >> "$LOG"
else
    echo "[list ] 未找到黑名单文件（App 启动一次后会自动生成）：$BLACK_FILE" >> "$LOG"
fi

# ---------- 7) 常驻巡检：APK 热更新 + 黑名单拦截 + 保活 + 拉起 ----------
cat > "$WATCH" <<'EOF'
#!/system/bin/sh
PKG=com.example.androidlauncher
HOME_ACT="$PKG/.ui.MainActivity"
LOG=/data/local/tmp/elder_launcher.log
DATA_DIR=/sdcard/Android/data/$PKG/files
BLACK_FILE=$DATA_DIR/elder_blacklist.txt
WHITE_FILE=$DATA_DIR/elder_whitelist.txt
DEF_BLACK=/data/local/tmp/elder_default_blacklist.txt
INSTALL_FLAG=$DATA_DIR/elder_install_block.txt
INSTALL_LIST=/data/local/tmp/elder_installer_blocklist.txt
MARKET_LIST=/data/local/tmp/elder_market_blocklist.txt
INST_MODE=/data/local/tmp/elder_install_mode
ACC_MISS=/data/local/tmp/elder_acc_miss
CLEAN_MARK=/data/local/tmp/elder_last_clean   # 上次「每小时强制清理」的时间戳
MARK=/data/local/tmp/elder_apk.md5
FAILMARK=/data/local/tmp/elder_apk_fail
TMP_APK=/data/local/tmp/elder_install.apk
UPDATE_DIR=/data/local/tmp/elder_update
NO_AUTOUPDATE=/data/adb/elder_no_autoupdate

# 自己别被系统回收（巡检脚本必须常驻）
echo -1000 > /proc/$$/oom_score_adj 2>/dev/null
echo -17   > /proc/$$/oom_adj       2>/dev/null

# 当前前台包名：Android 12+ 用 mResumedActivity，逐级降级兜底
top_pkg() {
    local out p
    out=$(dumpsys activity activities 2>/dev/null)
    p=$(echo "$out" | sed -n 's/.*mResumedActivity: ActivityRecord{[^ ]* \([a-zA-Z0-9._-]*\)\/.*/\1/p' | head -1)
    [ -n "$p" ] || p=$(echo "$out" | sed -n 's/.*topResumedActivity=ActivityRecord{[^ ]* \([a-zA-Z0-9._-]*\)\/.*/\1/p' | head -1)
    [ -n "$p" ] || p=$(dumpsys window 2>/dev/null | sed -n 's/.*mCurrentFocus=[^{]*{[^ ]* \([a-zA-Z0-9._-]*\)\/.*/\1/p' | head -1)
    [ -n "$p" ] || p=$(echo "$out" | sed -n 's/.* u0 \([a-zA-Z0-9._-]*\)\/.*/\1/p' | head -1)
    echo "$p"
}

# 给桌面进程写 oom_score_adj
oom_hard() {
    for d in /proc/[0-9]*; do
        pid=${d#/proc/}
        cmd=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
        case "$cmd" in
            *"$PKG"*)
                echo -1000 > "/proc/$pid/oom_score_adj" 2>/dev/null
                echo -17   > "/proc/$pid/oom_adj"       2>/dev/null
                ;;
        esac
    done
}

find_apk() {
    local f
    for f in \
        /sdcard/ElderLauncher.apk \
        /sdcard/Download/ElderLauncher.apk \
        /data/local/tmp/ElderLauncher.apk; do
        [ -f "$f" ] && { echo "$f"; return 0; }
    done
    ls -t "$UPDATE_DIR"/*.apk 2>/dev/null | head -1
    return 0
}

# 运行时权限（READ_PHONE_STATE=通话免提、CAMERA=手电筒、存储=壁纸）掉了就补上
ACC="$PKG/.service.LauncherAccessibilityService"
need_perm() {
    cmd package check-permission "$1" "$PKG" 2>/dev/null | grep -qi "true" && return 1
    return 0
}
grant_perms() {
    for p in \
        android.permission.READ_PHONE_STATE \
        android.permission.CAMERA \
        android.permission.READ_EXTERNAL_STORAGE \
        android.permission.READ_MEDIA_IMAGES; do
        if need_perm "$p"; then
            pm grant "$PKG" "$p" >> "$LOG" 2>&1
            echo "[perm ] $(date '+%F %T') re-grant $p -> $?" >> "$LOG"
        fi
    done
}
ensure_accessibility() {
    local cur new
    cur=$(settings get secure enabled_accessibility_services 2>/dev/null)
    case "$cur" in
        *"$ACC"*) : ;;
        *)
            if [ -z "$cur" ] || [ "$cur" = "null" ]; then
                new="$ACC"
            else
                new="$cur:$ACC"
            fi
            settings put secure enabled_accessibility_services "$new" >> "$LOG" 2>&1
            echo "[acc  ] $(date '+%F %T') re-enable -> $new" >> "$LOG"
            ;;
    esac
    settings put secure accessibility_enabled 1 >> "$LOG" 2>&1
}

# 安装策略：block = 只留 adb 安装（冻结应用市场、撤销第三方安装权限）
#           allow = 恢复手机端安装（解冻市场）
apply_install_policy() {
    local mode="$1" p m
    if [ "$mode" = "block" ]; then
        settings put secure install_non_market_apps 0 >> "$LOG" 2>&1
        settings put global install_non_market_apps 0 >> "$LOG" 2>&1
        for m in $(cat "$MARKET_LIST" 2>/dev/null); do
            pm disable-user --user 0 "$m" >> "$LOG" 2>&1
            appops set "$m" REQUEST_INSTALL_PACKAGES deny >> "$LOG" 2>&1
        done
        for p in $(pm list packages -3 2>/dev/null | cut -d: -f2); do
            [ "$p" = "$PKG" ] && continue
            appops set "$p" REQUEST_INSTALL_PACKAGES deny >> "$LOG" 2>&1
        done
        echo "[inst ] 策略：仅允许 adb 安装（市场已冻结）" >> "$LOG"
    else
        settings put secure install_non_market_apps 1 >> "$LOG" 2>&1
        settings put global install_non_market_apps 1 >> "$LOG" 2>&1
        for m in $(cat "$MARKET_LIST" 2>/dev/null); do
            pm enable "$m" >> "$LOG" 2>&1
            appops set "$m" REQUEST_INSTALL_PACKAGES allow >> "$LOG" 2>&1
        done
        for p in $(pm list packages -3 2>/dev/null | cut -d: -f2); do
            appops set "$p" REQUEST_INSTALL_PACKAGES allow >> "$LOG" 2>&1
        done
        echo "[inst ] 策略：允许手机端安装（市场已解冻）" >> "$LOG"
    fi
}

# 默认 HOME 是否还是我们（APK 升级 / 模块重刷后系统常把它清掉）
home_ok() {
    cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null | grep -q "$PKG"
}
restore_home() {
    cmd package set-home-activity "$HOME_ACT" >> "$LOG" 2>&1
    cmd role add-role-holder android.app.role.HOME "$PKG" 0 >> "$LOG" 2>&1
}

# 无障碍守护服务是否「真的在运行」
# （APK 被 pm install 升级后，系统会禁用本包的无障碍服务 → 回弹失效，
#   老人按最近任务键就能跑到别的 App / 原厂桌面，这是「锁不住」的头号原因）
acc_running() {
    dumpsys accessibility 2>/dev/null | grep -q "$PKG"
}
check_acc() {
    if acc_running; then
        rm -f "$ACC_MISS" 2>/dev/null
        return 0
    fi
    local n
    n=$(cat "$ACC_MISS" 2>/dev/null)
    [ -n "$n" ] || n=0
    n=$((n + 1))
    echo "$n" > "$ACC_MISS"
    echo "[acc  ] $(date '+%F %T') 守护服务未运行（第 $n 次）" >> "$LOG"
    # 连续 3 次（约 3 分钟）都没运行才动手重启，避免开机初期误判
    if [ "$n" -ge 3 ]; then
        echo "[acc  ] 连续未运行 -> 重新启用服务并重启桌面" >> "$LOG"
        ensure_accessibility
        am force-stop "$PKG" >> "$LOG" 2>&1
        sleep 2
        am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
        sleep 4
        oom_hard
        rm -f "$ACC_MISS" 2>/dev/null
    fi
}

apk_md5() {
    local s
    s=$(md5sum "$1" 2>/dev/null | cut -d' ' -f1)
    [ -n "$s" ] || s="s$(wc -c < "$1" 2>/dev/null)-$(date -r "$1" +%s 2>/dev/null)"
    echo "$s"
}

# 热更新：APK 指纹变了就自动重装 + 重新拉起桌面（不用重启、不用重刷模块）
auto_update() {
    [ -f "$NO_AUTOUPDATE" ] && return 0
    local src sum last failed rc out
    src=$(find_apk)
    [ -z "$src" ] && return 0
    sum=$(apk_md5 "$src")
    [ -z "$sum" ] && return 0
    last=$(cat "$MARK" 2>/dev/null)
    failed=$(cat "$FAILMARK" 2>/dev/null)
    [ "$sum" = "$last" ] && return 0
    [ "$sum" = "$failed" ] && return 0

    echo "[apk  ] $(date '+%F %T') 发现新 APK：$src -> 自动安装" >> "$LOG"
    cp -f "$src" "$TMP_APK" 2>/dev/null
    [ -f "$TMP_APK" ] || TMP_APK="$src"
    out=$(pm install -r -g --user 0 "$TMP_APK" 2>&1)
    rc=$?
    echo "$out" >> "$LOG"
    if [ "$rc" -eq 0 ]; then
        echo "$sum" > "$MARK"
        rm -f "$FAILMARK" 2>/dev/null
        echo "[apk  ] 更新完成，重启桌面" >> "$LOG"
        am force-stop "$PKG" >> "$LOG" 2>&1
        sleep 2
        am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
        sleep 3
        oom_hard
    else
        case "$out" in
            *DOWNGRADE*)
                # 手机上已装的更新（例如 adb/Studio 装的），不降级
                echo "$sum" > "$MARK"
                echo "[apk  ] 手机上已装的更新，跳过（不降级）" >> "$LOG"
                ;;
            *)
                echo "$sum" > "$FAILMARK"
                echo "[apk  ] 自动安装失败 rc=$rc（换新的 APK 才会再试）" >> "$LOG"
                ;;
        esac
    fi
}

# ---------- 每小时强制清理：只留老人桌面 / 微信 / 电话 ----------
# 用 am force-stop（等价于设置里的「强行停止」，连后台服务与推送一起停），
# 范围限定为「第三方应用」（pm list packages -3），系统进程天然碰不到；
# 另保留：本桌面、微信、电话相关（拨号 / 通话 / 联系人 / 短信）、当前前台应用
# （老人正在用的那个不打断）。
hourly_cleanup() {
    local top n=0 p tts
    top=$(top_pkg)
    # ★ TTS 引擎必须保住：拨号盘按数字要语音报号，引擎被 force-stop 后就再也不出声
    tts=$(settings get secure tts_default_synth 2>/dev/null)
    case "$tts" in
        null | "") tts="" ;;
    esac
    echo "[clean] $(date '+%F %T') 每小时清理开始（保留前台：$top，TTS：$tts）" >> "$LOG"
    for p in $(pm list packages -3 2>/dev/null | sed 's/^package://'); do
        case "$p" in
            "$PKG"|com.tencent.mm|com.android.phone|com.android.server.telecom|com.android.dialer|com.android.contacts|com.android.mms) continue ;;
            # 常见语音引擎兜底保留（系统 TTS 不在 -3 列表，这里防第三方引擎）
            com.google.android.tts|com.iflytek.speechsuite|com.baidu.speech.tts|com.xiaomi.mibrain.speech) continue ;;
        esac
        [ -n "$tts" ] && [ "$p" = "$tts" ] && continue
        [ "$p" = "$top" ] && continue
        am force-stop "$p" >> "$LOG" 2>&1
        n=$((n + 1))
    done
    echo "[clean] 清理完成，共停止 $n 个第三方应用" >> "$LOG"
    # 清完确保老人桌面在最前
    am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
}

# 到点才清：用时间戳判断（不受巡检间隔漂移影响），首次启动后满 1 小时才清
hourly_cleanup_if_due() {
    local now last
    now=$(date +%s)
    last=$(cat "$CLEAN_MARK" 2>/dev/null)
    [ -n "$last" ] || last=0
    [ $((now - last)) -ge 3600 ] || return 0
    echo "$now" > "$CLEAN_MARK"
    hourly_cleanup
}

round=0
while true; do
    round=$((round + 1))

    # (0) 每 60 秒检查一次「距上次清理是否已满 1 小时」
    if [ $((round % 12)) -eq 0 ]; then
        hourly_cleanup_if_due
    fi

    # (1) 每 30 秒补写一次 oom_score_adj
    if [ $((round % 6)) -eq 1 ]; then
        oom_hard
    fi

    # (2) 每 60 秒检查一次 APK 是否更新（热更新）
    if [ $((round % 12)) -eq 6 ]; then
        auto_update
        # 刚装完 APK，系统很可能顺手清掉默认 HOME → 立刻补回来
        home_ok || restore_home
    fi

    # (2.6) 每 60 秒同步「强制阻止安装模式」开关；每 10 分钟强制加固一次
    #       （强制加固的意义：新装的第三方 App 默认有安装权限，要重新 deny）
    if [ $((round % 12)) -eq 3 ]; then
        want=allow
        [ "$(cat "$INSTALL_FLAG" 2>/dev/null)" = "1" ] && want=block
        if [ "$want" = "block" ] && [ $((round % 120)) -eq 3 ]; then
            apply_install_policy block
            echo block > "$INST_MODE"
        else
            cur=$(cat "$INST_MODE" 2>/dev/null)
            if [ "$cur" != "$want" ]; then
                echo "[inst ] $(date '+%F %T') 安装模式开关：${cur:-未设置} -> $want" >> "$LOG"
                apply_install_policy "$want"
                echo "$want" > "$INST_MODE"
            fi
        fi
    fi

    # (2.5) 每 60 秒补一次运行时权限 / 无障碍 / 默认桌面（APK 重装或被系统重置后会掉）
    if [ $((round % 12)) -eq 9 ]; then
        grant_perms
        ensure_accessibility
        check_acc
        if ! home_ok; then
            echo "[home ] $(date '+%F %T') 默认桌面被重置 -> 恢复" >> "$LOG"
            restore_home
        fi
    fi

    # 本轮前台应用：只查一次，下面的检查统一复用
    cur_top=$(top_pkg)

    # (2.8) ★ 强制阻止安装模式：出现「安装器 / 应用市场」界面 → 切断安装 + 回桌面
    #        （只拦新安装，不会卸载任何已安装的应用）
    if [ "$(cat "$INSTALL_FLAG" 2>/dev/null)" = "1" ]; then
        if [ -n "$cur_top" ] && [ "$cur_top" != "$PKG" ] && grep -qx "$cur_top" "$INSTALL_LIST" 2>/dev/null; then
            echo "[inst ] $(date '+%F %T') 检测到安装界面 $cur_top -> 切断安装并回桌面" >> "$LOG"
            am force-stop "$cur_top" >> "$LOG" 2>&1
            am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
        fi
    fi

    # (3) 拦截：内置名单（别的桌面）兜底 + App 导出的黑名单（★ 不能用 am kill-all：
    #     它会把桌面进程、无障碍服务、以及本巡检脚本一起杀掉，导致只能拦一次）
    if [ -f "$DEF_BLACK" ]; then
        top=$cur_top
        if [ -n "$top" ] && [ "$top" != "$PKG" ]; then
            # 内置名单命中 → 不强杀（系统桌面强杀会让 SystemUI 闪一下），只拉回老人桌面
            if grep -qx "$top" "$DEF_BLACK" 2>/dev/null; then
                echo "[block] $(date '+%F %T') 跑到别的桌面 $top -> 拉回老人桌面" >> "$LOG"
                am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
                sleep 1
                [ "$(top_pkg)" = "$top" ] && am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
            elif [ -f "$BLACK_FILE" ] && grep -qx "$top" "$BLACK_FILE" 2>/dev/null; then
                echo "[block] $(date '+%F %T') 命中黑名单 $top -> 强杀 + 回桌面" >> "$LOG"
                am force-stop "$top" >> "$LOG" 2>&1
                am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
                # 复查：被杀后自启的再杀一次（最多 2 轮）
                n=0
                while [ "$n" -lt 2 ]; do
                    n=$((n + 1))
                    sleep 1
                    t2=$(top_pkg)
                    [ "$t2" = "$top" ] || break
                    echo "[block] $(date '+%F %T') 复查仍在前台 $top -> 再次强杀（第 $n 次）" >> "$LOG"
                    am force-stop "$top" >> "$LOG" 2>&1
                    am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
                done
            fi
        fi
    fi

    # (4) 桌面进程没了就拉起
    found=0
    for d in /proc/[0-9]*; do
        pid=${d#/proc/}
        cmd=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
        case "$cmd" in
            *"$PKG"*)
                found=1
                echo -1000 > "/proc/$pid/oom_score_adj" 2>/dev/null
                echo -17   > "/proc/$pid/oom_adj"       2>/dev/null
                ;;
        esac
    done
    if [ "$found" = "0" ]; then
        echo "[watch] $(date '+%F %T') 桌面进程不存在，重新拉起" >> "$LOG"
        am start -a android.intent.action.MAIN -c android.intent.category.HOME -n "$HOME_ACT" >> "$LOG" 2>&1
        sleep 5
        oom_hard
    fi

    sleep 5
done
EOF
chmod 0755 "$WATCH" 2>/dev/null

if [ ! -f /data/adb/elder_no_watchdog ]; then
    # 先清掉可能残留的旧巡检（用 /proc 扫描，避免 ps|grep 自匹配问题）
    for d in /proc/[0-9]*; do
        pid=${d#/proc/}
        cmd=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
        case "$cmd" in
            *"elder_watchdog.sh"*)
                [ "$pid" = "$$" ] || kill -9 "$pid" 2>/dev/null
                ;;
        esac
    done
    nohup "$WATCH" >> "$LOG" 2>&1 &
    echo "[watch] watchdog started" >> "$LOG"
else
    echo "[watch] 已关闭（/data/adb/elder_no_watchdog 存在）" >> "$LOG"
fi

echo "[done ] service.sh finished" >> "$LOG"
exit 0
