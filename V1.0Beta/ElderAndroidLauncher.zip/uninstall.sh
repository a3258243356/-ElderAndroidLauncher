#!/system/bin/sh
# 卸载模块时执行：停掉巡检、清理白名单与临时文件（保留 App 与老人配置数据）

PKG=com.example.androidlauncher
LOG=/data/local/tmp/elder_launcher.log
WATCH=/data/local/tmp/elder_watchdog.sh

echo "==== $(date '+%F %T') uninstall ====" >> "$LOG"

# 1) 停掉常驻巡检
for d in /proc/[0-9]*; do
    pid=${d#/proc/}
    cmd=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
    case "$cmd" in
        *"elder_watchdog.sh"*)
            echo "[watch] kill $pid" >> "$LOG"
            kill -9 "$pid" 2>/dev/null
            ;;
    esac
done
rm -f "$WATCH" 2>/dev/null
rm -f /data/local/tmp/elder_apk.md5 /data/local/tmp/elder_apk_fail /data/local/tmp/elder_install.apk 2>/dev/null

# 2) 恢复省电策略
cmd appops set "$PKG" RUN_IN_BACKGROUND default >> "$LOG" 2>&1
cmd appops set "$PKG" RUN_ANY_IN_BACKGROUND default >> "$LOG" 2>&1
cmd appops set "$PKG" START_FOREGROUND default >> "$LOG" 2>&1
dumpsys deviceidle whitelist -"$PKG" >> "$LOG" 2>&1

# 注意：不要把默认桌面清掉，否则手机可能没有 Home 可用。
# 如需恢复原厂桌面，手动执行：
#   adb shell cmd package set-home-activity com.android.launcher3/.Launcher
echo "[done ] uninstall finished" >> "$LOG"
exit 0
